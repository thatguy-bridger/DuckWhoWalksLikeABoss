const url = 'chrome-extension://' + chrome.runtime.id + '/assets/';



const defaultScrubber = document.querySelector('.ytp-scrubber-button');
const toggleCurrentVideo = (component = defaultScrubber, scrubberPass) => {
	if(component){
		component.style.display = 'none';
	}
	const scrubber = scrubberPass || document.querySelectorAll('.ytp-scrubber-container');
	scrubber.forEach(item => {
		if(item.querySelectorAll('.duck-walking-likeaboss').length){
			return
		}
		const image = document.createElement('img');
		image.src = url+'ducky.gif';
		image.className = 'duck-walking-likeaboss';

		item.append(image)
	})
}
toggleCurrentVideo();







